# Template for `snakemake` demo

Author: Kosmas Hench

This repo is the starting point for the `snakemake` exercise of the topic workshop on reproducible coding by the DFG Priority Program 1158
"Antarctic Research with comparative investigations in Arctic ice areas".